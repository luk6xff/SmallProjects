NXP's documentation for their peripheral driver library can be found
as a Microsoft Compiled HTML Help file (.chm) within the LPC18xx 
CMSIS Standard Peripheral Driver Library download on NXP's website.

At the time of writing, this can be found at the following link:

http://lpcware.com/file_filter/nxp?term_node_tid_depth=All&term_node_tid_depth_1=103


