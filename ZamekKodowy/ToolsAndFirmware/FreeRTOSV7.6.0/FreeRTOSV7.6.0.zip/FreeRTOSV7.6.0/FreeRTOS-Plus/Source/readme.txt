Directories:

+ The FreeRTOS-Plus/Source contains the source code of each FreeRTOS+ product.

+ See http://www.FreeRTOS.org for FreeRTOS documentation.  See
  http://www.freertos.org/plus for FreeRTOS+ documentation.

