/* dummy ecc.c for dist */
